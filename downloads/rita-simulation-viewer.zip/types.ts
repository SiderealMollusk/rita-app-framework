
export type LogLevel = 'INFO' | 'ERROR' | 'DEBUG' | 'TRACE';

export interface LogEntry {
  timestamp: string;
  level: LogLevel;
  traceId: string;
  spanId: string;
  component: string;
  message: string;
  metadata: Record<string, any>;
  snapshot?: Record<string, any>;
  evolution?: Record<string, any>;
  reason?: string;
}

export type TimelineViewMode = 'linear' | 'trace';

export interface TraceGroup {
  traceId: string;
  logs: LogEntry[];
  startTime: string;
}
