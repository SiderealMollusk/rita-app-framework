
import React from 'react';
import { LogEntry, TimelineViewMode, TraceGroup } from '../types';
import { Clock, Info, AlertTriangle, Bug, Zap } from 'lucide-react';

interface TimelineProps {
  logs: LogEntry[];
  traces: TraceGroup[];
  viewMode: TimelineViewMode;
  activeIndex: number;
  onSelect: (index: number) => void;
}

const getComponentColor = (component: any) => {
  if (!component || typeof component !== 'string') {
    return 'text-slate-400 border-zinc-700/50 bg-zinc-800/20';
  }
  
  try {
    const c = component.toLowerCase();
    if (c.includes('interaction') || c.includes('sim:')) return 'text-emerald-400 border-emerald-500/30 bg-emerald-500/5';
    if (c.includes('usecase') || c.includes('workflow')) return 'text-blue-400 border-blue-500/30 bg-blue-500/5';
    if (c.includes('policy')) return 'text-purple-400 border-purple-500/30 bg-purple-500/5';
    if (c.includes('gateway') || c.includes('adapter')) return 'text-amber-400 border-amber-500/30 bg-amber-500/5';
  } catch (e) {
    // Fallback if somehow toLowerCase fails
  }
  
  return 'text-slate-400 border-zinc-700/50 bg-zinc-800/20';
};

const getLevelIcon = (level: string) => {
  switch (level) {
    case 'ERROR': return <AlertTriangle size={12} className="text-rose-500" />;
    case 'DEBUG': return <Bug size={12} className="text-zinc-500" />;
    case 'TRACE': return <Zap size={12} className="text-amber-500" />;
    default: return <Info size={12} className="text-emerald-500" />;
  }
};

const Timeline: React.FC<TimelineProps> = ({ logs, traces, viewMode, activeIndex, onSelect }) => {
  if (viewMode === 'trace') {
    return (
      <div className="p-4 space-y-8 pb-20">
        {traces.map((trace) => (
          <div key={trace.traceId} className="relative">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px flex-1 bg-zinc-800" />
              <div className="px-2 py-0.5 rounded border border-zinc-800 bg-zinc-900 text-[9px] font-mono text-zinc-500 uppercase tracking-widest max-w-[180px] truncate">
                {trace.traceId.includes('untraced') ? 'System' : `Trace: ${trace.traceId.slice(0, 8)}...`}
              </div>
              <div className="h-px flex-1 bg-zinc-800" />
            </div>
            
            <div className="space-y-3 relative">
              <div className="absolute left-[11px] top-3 bottom-3 w-px bg-zinc-800/60" />

              {trace.logs.map((log, logIdx) => {
                const globalIndex = logs.indexOf(log);
                const isActive = activeIndex === globalIndex;
                const colors = getComponentColor(log.component);

                return (
                  <button
                    key={`${log.spanId || 'log'}-${globalIndex}-${logIdx}`}
                    onClick={() => onSelect(globalIndex)}
                    className={`w-full text-left group flex items-start gap-4 transition-all duration-200 outline-none
                      ${isActive ? 'scale-[1.02] transform' : 'opacity-70 hover:opacity-100 hover:translate-x-1'}
                    `}
                  >
                    <div className={`mt-1.5 w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 z-10 transition-colors
                      ${isActive ? 'bg-zinc-950 border-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.3)]' : 'bg-zinc-900 border-zinc-700'}
                    `}>
                      {isActive ? <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" /> : getLevelIcon(log.level)}
                    </div>

                    <div className={`flex-1 p-3 rounded-lg border transition-all
                      ${isActive ? 'bg-zinc-900/80 border-emerald-500/50 text-white' : 'bg-zinc-900/20 border-zinc-800 text-zinc-400 group-hover:border-zinc-700'}
                    `}>
                      <div className="flex justify-between items-start mb-1">
                        <span className={`text-[10px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded ${colors}`}>
                          {log.component || 'SYSTEM'}
                        </span>
                        <span className="text-[9px] font-mono text-zinc-600">
                          {new Date(log.timestamp).toLocaleTimeString([], { hour12: false, fractionalSecondDigits: 3 } as any)}
                        </span>
                      </div>
                      <p className={`text-xs leading-relaxed font-medium ${isActive ? 'text-zinc-200' : 'text-zinc-400'}`}>
                        {log.message}
                      </p>
                      {log.reason && (
                        <div className="mt-2 text-[10px] italic text-zinc-500 border-l border-zinc-800 pl-2">
                          Reason: {log.reason}
                        </div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="p-4 space-y-3 pb-20 relative">
      <div className="absolute left-[27px] top-6 bottom-6 w-px bg-zinc-800/40" />
      {logs.map((log, idx) => {
        const isActive = activeIndex === idx;
        const colors = getComponentColor(log.component);
        return (
          <button
            key={`${idx}-${log.spanId || 'log'}`}
            onClick={() => onSelect(idx)}
            className={`w-full text-left flex items-start gap-4 group transition-all duration-200
              ${isActive ? 'translate-x-1 scale-[1.01]' : 'opacity-60 hover:opacity-100'}
            `}
          >
            <div className={`mt-1 w-6 h-6 rounded-md border flex items-center justify-center shrink-0 z-10 transition-all
               ${isActive ? 'bg-emerald-500 border-emerald-400 shadow-lg shadow-emerald-500/20 text-zinc-950' : 'bg-zinc-900 border-zinc-800 text-zinc-500'}
            `}>
              {isActive ? <Clock size={12} /> : <div className="text-[10px] font-mono">{idx + 1}</div>}
            </div>

            <div className={`flex-1 p-3 rounded-xl border transition-all
              ${isActive ? 'bg-zinc-800 border-emerald-500/50 ring-1 ring-emerald-500/20' : 'bg-zinc-900/40 border-zinc-800 group-hover:border-zinc-700'}
            `}>
              <div className="flex justify-between items-center mb-1.5">
                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wider ${colors}`}>
                   {log.component || 'SYSTEM'}
                </span>
                <span className="text-[9px] font-mono text-zinc-600">{new Date(log.timestamp).toLocaleTimeString([], { hour12: false, fractionalSecondDigits: 2 } as any)}</span>
              </div>
              <p className="text-xs font-medium text-zinc-300 line-clamp-2">{log.message}</p>
              {log.snapshot && (
                <div className="mt-2 flex items-center gap-1.5 text-[9px] text-zinc-500 font-mono">
                   <div className="w-1.5 h-1.5 rounded-full bg-blue-500/50" />
                   Snapshot Recorded
                </div>
              )}
            </div>
          </button>
        );
      })}
    </div>
  );
};

export default Timeline;
