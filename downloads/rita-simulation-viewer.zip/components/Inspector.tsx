
import React from 'react';
import { LogEntry } from '../types';
import { Terminal, Copy, Check } from 'lucide-react';

interface InspectorProps {
  log: LogEntry | null;
}

const Inspector: React.FC<InspectorProps> = ({ log }) => {
  const [copied, setCopied] = React.useState(false);

  const copyToClipboard = () => {
    if (!log) return;
    navigator.clipboard.writeText(JSON.stringify(log, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!log) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-zinc-700 p-8 text-center opacity-40">
        <Terminal size={40} strokeWidth={1} className="mb-4" />
        <p className="text-xs font-medium uppercase tracking-widest">Metadata Inspector Ready</p>
        <p className="text-[10px] mt-2 max-w-[200px]">Select a log entry to view raw metadata and schema validation details.</p>
      </div>
    );
  }

  const shortSpan = log.spanId ? log.spanId.slice(0, 8) : 'unknown';
  const shortTrace = log.traceId ? log.traceId.slice(0, 8) : 'untraced';

  return (
    <div className="flex flex-col h-full bg-zinc-950">
      <div className="p-4 border-b border-zinc-900 flex justify-between items-center shrink-0">
        <div className="flex items-center gap-2">
           <span className="text-[10px] bg-zinc-900 text-zinc-500 px-2 py-0.5 rounded font-mono uppercase">
             ID: {shortSpan}
           </span>
        </div>
        <button 
          onClick={copyToClipboard}
          className="text-zinc-500 hover:text-white transition-colors"
          title="Copy JSON"
        >
          {copied ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
        </button>
      </div>

      <div className="flex-1 overflow-auto p-4 custom-scrollbar">
        <div className="space-y-6">
          {/* Main Info */}
          <div className="space-y-3">
             <label className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest block">System Context</label>
             <div className="grid grid-cols-2 gap-2">
                <div className="bg-zinc-900/50 p-2 rounded-lg border border-zinc-900">
                  <span className="text-[9px] text-zinc-500 uppercase block mb-1">Level</span>
                  <span className={`text-xs font-mono ${log.level === 'ERROR' ? 'text-rose-400' : 'text-zinc-300'}`}>{log.level}</span>
                </div>
                <div className="bg-zinc-900/50 p-2 rounded-lg border border-zinc-900">
                  <span className="text-[9px] text-zinc-500 uppercase block mb-1">Trace ID</span>
                  <span className="text-xs font-mono text-zinc-300 truncate" title={log.traceId}>{shortTrace}...</span>
                </div>
             </div>
          </div>

          {/* Metadata Tree */}
          <div className="space-y-3">
             <label className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest block">Raw Payload</label>
             <pre className="text-[11px] font-mono text-zinc-400 leading-relaxed bg-zinc-900/30 p-4 rounded-xl border border-zinc-900 overflow-x-auto">
               {JSON.stringify(log.metadata || {}, null, 2)}
             </pre>
          </div>

          {/* Timing details */}
          <div className="space-y-3">
             <label className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest block">Timing & Clocks</label>
             <div className="bg-zinc-900/50 p-3 rounded-xl border border-zinc-900 flex flex-col gap-2">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] text-zinc-500">ISO8601</span>
                  <span className="text-[10px] font-mono text-zinc-300">{log.timestamp}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[10px] text-zinc-500">Epoch</span>
                  <span className="text-[10px] font-mono text-zinc-300">{new Date(log.timestamp).getTime()}</span>
                </div>
             </div>
          </div>

          {/* Component Span */}
          <div className="space-y-3">
             <label className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest block">Execution Span</label>
             <div className="p-3 rounded-xl border border-emerald-500/10 bg-emerald-500/[0.02] flex items-center justify-between">
                <div className="flex items-center gap-2">
                   <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                   <span className="text-xs text-zinc-300 font-medium">{log.component || 'System Context'}</span>
                </div>
                <span className="text-[9px] font-mono text-zinc-600 italic">ID: {shortSpan}</span>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Inspector;
