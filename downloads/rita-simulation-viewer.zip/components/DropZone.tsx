
import React, { useState } from 'react';
import { Upload, FileText, Activity, Layers, ShieldCheck } from 'lucide-react';

interface DropZoneProps {
  onDrop: (content: string) => void;
}

const DropZone: React.FC<DropZoneProps> = ({ onDrop }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        onDrop(event.target?.result as string);
      };
      reader.readAsText(file);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        onDrop(event.target?.result as string);
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="h-screen w-screen bg-[#09090b] flex items-center justify-center p-6 font-sans">
      <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div className="space-y-4">
            <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-500 shadow-2xl shadow-emerald-500/10">
              <Activity size={24} />
            </div>
            <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
              Rita Simulation <br />
              <span className="text-emerald-500">Visualizer</span>
            </h1>
            <p className="text-lg text-zinc-400 leading-relaxed max-w-sm">
              The high-fidelity execution viewer for the Rita Framework. 
              Analyze traces, inspect state snapshots, and time-travel through logs.
            </p>
          </div>

          <div className="space-y-6">
            <div className="flex items-start gap-4">
               <div className="mt-1 w-8 h-8 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center shrink-0">
                  <Layers size={14} className="text-emerald-500" />
               </div>
               <div>
                  <h3 className="text-sm font-semibold text-zinc-200">Trace Centric</h3>
                  <p className="text-xs text-zinc-500 leading-normal">Automatically groups events by Trace ID for complex workflow visualization.</p>
               </div>
            </div>
            <div className="flex items-start gap-4">
               <div className="mt-1 w-8 h-8 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center shrink-0">
                  <ShieldCheck size={14} className="text-emerald-500" />
               </div>
               <div>
                  <h3 className="text-sm font-semibold text-zinc-200">State Snapshots</h3>
                  <p className="text-xs text-zinc-500 leading-normal">Deep-inspect entity evolution with automatic diff highlighting.</p>
               </div>
            </div>
          </div>
        </div>

        <div 
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`
            relative aspect-square rounded-[2rem] border-2 border-dashed flex flex-col items-center justify-center text-center p-10 transition-all duration-300 overflow-hidden
            ${isDragging ? 'bg-emerald-500/5 border-emerald-500 scale-[1.02]' : 'bg-zinc-950/50 border-zinc-800 hover:border-zinc-700'}
          `}
        >
          {/* Animated background elements */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
             <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-emerald-500/20 blur-[100px] rounded-full" />
             <div className="absolute bottom-1/4 right-1/4 w-32 h-32 bg-blue-500/20 blur-[100px] rounded-full" />
          </div>

          <div className="z-10 flex flex-col items-center">
            <div className={`
              w-20 h-20 rounded-3xl mb-6 flex items-center justify-center transition-all duration-300
              ${isDragging ? 'bg-emerald-500 text-zinc-950 scale-110 shadow-lg shadow-emerald-500/20' : 'bg-zinc-900 text-zinc-400'}
            `}>
              <Upload size={32} />
            </div>
            <h2 className="text-xl font-bold text-white mb-2">Drop simulation log</h2>
            <p className="text-xs text-zinc-500 mb-8 max-w-[200px] font-medium leading-relaxed uppercase tracking-wider">
               Accepts .jsonl files following the Governed Logging Specification V2
            </p>
            
            <label className="group relative">
               <input 
                 type="file" 
                 accept=".jsonl,.json" 
                 className="hidden" 
                 onChange={handleFileInput}
               />
               <div className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 px-8 py-3 rounded-full text-sm font-bold cursor-pointer transition-all active:scale-95 shadow-xl shadow-emerald-500/10">
                 Choose File
               </div>
            </label>
          </div>

          <div className="mt-12 flex items-center gap-6 text-[10px] font-mono text-zinc-600 uppercase tracking-widest z-10">
             <div className="flex items-center gap-2">
                <FileText size={12} />
                JSONL
             </div>
             <div className="w-1 h-1 rounded-full bg-zinc-800" />
             <div className="flex items-center gap-2">
                <Layers size={12} />
                TRACES
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DropZone;
