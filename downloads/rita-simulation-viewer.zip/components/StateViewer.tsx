
import React, { useMemo } from 'react';
import { LogEntry } from '../types';
import { Database, TrendingUp, HelpCircle, LayoutGrid, List, Zap } from 'lucide-react';

interface StateViewerProps {
  log: LogEntry | null;
  allLogs: LogEntry[];
  index: number;
}

const StateViewer: React.FC<StateViewerProps> = ({ log, allLogs, index }) => {
  // Find latest snapshot for the relevant entity if current log doesn't have one
  const snapshotToRender = useMemo(() => {
    if (!log) return null;
    if (log.snapshot) return log.snapshot;
    
    // Look backwards for the most recent snapshot for the same trace or entity type
    for (let i = index; i >= 0; i--) {
      if (allLogs[i].snapshot) return allLogs[i].snapshot;
    }
    return null;
  }, [log, allLogs, index]);

  const evolution = log?.evolution || {};

  if (!log) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-zinc-600 gap-4 opacity-50">
        <Database size={48} strokeWidth={1} />
        <p className="text-sm font-medium">Select an event to inspect state</p>
      </div>
    );
  }

  const renderValue = (key: string, value: any) => {
    const isEvolved = evolution && evolution.hasOwnProperty(key);
    
    if (Array.isArray(value)) {
      return (
        <div className="space-y-3">
          {value.map((item, idx) => (
            <div key={idx} className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-3">
               {renderObject(item)}
            </div>
          ))}
        </div>
      );
    }

    if (typeof value === 'object' && value !== null) {
      return (
        <div className="pl-4 border-l border-zinc-800 py-1 space-y-2">
           {renderObject(value)}
        </div>
      );
    }

    return (
      <span className={`font-mono text-sm break-all ${isEvolved ? 'text-emerald-400 bg-emerald-500/10 px-1 rounded' : 'text-zinc-300'}`}>
        {String(value)}
      </span>
    );
  };

  const renderObject = (obj: any) => {
    return Object.entries(obj).map(([key, value]) => (
      <div key={key} className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
           <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">{key}</span>
           {evolution.hasOwnProperty(key) && (
              <span className="text-[9px] bg-emerald-500/10 text-emerald-500 px-1 rounded border border-emerald-500/20">EVOLUTION</span>
           )}
        </div>
        {renderValue(key, value)}
      </div>
    ));
  };

  // Specialized view for Kitchen if detected
  const isKitchen = snapshotToRender?.items || snapshotToRender?.stations;

  return (
    <div className="p-8 max-w-5xl mx-auto w-full space-y-8 animate-in fade-in duration-500">
      {/* State Header Card */}
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h2 className="text-2xl font-bold text-white tracking-tight">
              {snapshotToRender?.id || log.component}
            </h2>
            <div className="flex items-center gap-2 text-zinc-500 text-xs font-mono">
               <TrendingUp size={12} className="text-emerald-500" />
               Current State Snapshot
            </div>
          </div>
          <div className="flex items-center gap-2 bg-zinc-900 p-1 rounded-lg border border-zinc-800">
            <button className="p-1.5 text-emerald-400 bg-zinc-800 rounded-md shadow-sm">
               <LayoutGrid size={16} />
            </button>
            <button className="p-1.5 text-zinc-500 hover:text-zinc-300">
               <List size={16} />
            </button>
          </div>
        </div>

        {log.evolution && (
          <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-xl p-4 flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center shrink-0 border border-emerald-500/20 text-emerald-500">
               {/* Fixed: Zap is now correctly imported */}
               <Zap size={20} />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-emerald-400 uppercase tracking-widest">State Delta</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Component <span className="text-white font-mono">{log.component}</span> triggered an evolution 
                via <span className="text-white font-mono">{log.reason || 'unspecified reason'}</span>.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                 {Object.entries(log.evolution).map(([k, v]) => (
                   <span key={k} className="bg-emerald-500/10 text-[10px] font-mono text-emerald-400 px-2 py-1 rounded-md border border-emerald-500/10">
                      {k}: {String(v)}
                   </span>
                 ))}
              </div>
            </div>
          </div>
        )}

        {!snapshotToRender ? (
           <div className="bg-zinc-900/50 border border-dashed border-zinc-800 rounded-2xl p-20 flex flex-col items-center justify-center text-center gap-4">
              <HelpCircle size={40} className="text-zinc-700" />
              <div className="space-y-1">
                <p className="text-sm font-medium text-zinc-400">No Snapshot Data</p>
                <p className="text-xs text-zinc-600 max-w-[240px]">This event log doesn't contain a domain snapshot and no previous snapshots were found in this trace.</p>
              </div>
           </div>
        ) : (
          <div className={`grid gap-6 ${isKitchen ? 'grid-cols-2' : 'grid-cols-1'}`}>
            {Object.entries(snapshotToRender).map(([key, value]) => {
              if (key === 'id' || key === 'status') return null; // Already shown or handled
              return (
                <div key={key} className="bg-zinc-900/30 border border-zinc-800/50 rounded-2xl p-6 shadow-sm hover:border-zinc-700 transition-colors">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-2 h-2 rounded-full bg-zinc-700" />
                    <h4 className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em]">{key}</h4>
                  </div>
                  {renderValue(key, value)}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default StateViewer;
