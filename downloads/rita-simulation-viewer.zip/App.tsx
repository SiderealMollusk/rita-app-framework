
import React, { useState, useMemo, useEffect } from 'react';
import { 
  Activity, 
  Clock, 
  Terminal, 
  Layers, 
  Play, 
  Pause, 
  FastForward, 
  Rewind,
  Upload,
  Box,
  Database
} from 'lucide-react';
import { LogEntry, TimelineViewMode, TraceGroup } from './types';
import Timeline from './components/Timeline';
import StateViewer from './components/StateViewer';
import Inspector from './components/Inspector';
import DropZone from './components/DropZone';

const App: React.FC = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(-1);
  const [viewMode, setViewMode] = useState<TimelineViewMode>('linear');
  const [isPlaying, setIsPlaying] = useState(false);

  // Grouped Traces for Pulse Panel
  const traces = useMemo(() => {
    const map = new Map<string, TraceGroup>();
    logs.forEach(log => {
      // Handle logs without traceId by grouping under a virtual 'system' trace
      const tid = log.traceId || 'untraced-system-events';
      if (!map.has(tid)) {
        map.set(tid, { traceId: tid, logs: [], startTime: log.timestamp });
      }
      map.get(tid)?.logs.push(log);
    });
    return Array.from(map.values()).sort((a, b) => 
      new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
    );
  }, [logs]);

  // Selected Log based on timeline position
  const activeLog = logs[currentIndex] || null;

  // Auto-play logic
  useEffect(() => {
    let interval: any;
    if (isPlaying && currentIndex < logs.length - 1) {
      interval = setInterval(() => {
        setCurrentIndex(prev => prev + 1);
      }, 500);
    } else {
      setIsPlaying(false);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentIndex, logs.length]);

  const handleFileDrop = (fileContent: string) => {
    try {
      const parsedLogs: LogEntry[] = fileContent
        .split('\n')
        .filter(line => line.trim())
        .map(line => JSON.parse(line));
      
      const sortedLogs = parsedLogs.sort((a, b) => 
        new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      );
      
      setLogs(sortedLogs);
      setCurrentIndex(0);
    } catch (err) {
      console.error(err);
      alert("Error parsing JSONL file. Ensure it follows the Rita Logging Spec.");
    }
  };

  if (logs.length === 0) {
    return <DropZone onDrop={handleFileDrop} />;
  }

  return (
    <div className="flex flex-col h-screen bg-[#09090b] text-slate-200">
      {/* Header */}
      <header className="h-14 border-b border-zinc-800 flex items-center justify-between px-6 bg-zinc-950/50 backdrop-blur-md shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-emerald-500/10 rounded-lg flex items-center justify-center text-emerald-500 border border-emerald-500/20">
            <Activity size={18} />
          </div>
          <div>
            <h1 className="font-semibold text-sm tracking-tight">RITA SIMULATION VIEWER</h1>
            <p className="text-[10px] text-zinc-500 font-mono uppercase tracking-widest leading-none">V2.1.0-STABLE</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1 bg-zinc-900 rounded-lg p-1 border border-zinc-800">
            <button 
              onClick={() => setViewMode('linear')}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${viewMode === 'linear' ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              Linear
            </button>
            <button 
              onClick={() => setViewMode('trace')}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${viewMode === 'trace' ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-400 hover:text-zinc-200'}`}
            >
              Trace View
            </button>
          </div>
          <button 
            onClick={() => { setLogs([]); setCurrentIndex(-1); }}
            className="flex items-center gap-2 text-xs font-medium text-zinc-400 hover:text-emerald-400 transition-colors bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg"
          >
            <Upload size={14} />
            New Simulation
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex overflow-hidden">
        {/* Left Panel: The Pulse */}
        <section className="w-[380px] border-r border-zinc-800 flex flex-col shrink-0 bg-zinc-950/20">
          <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-zinc-400 font-medium text-xs">
              <Layers size={14} />
              THE PULSE
            </div>
            <span className="text-[10px] font-mono text-zinc-600">{logs.length} EVENTS</span>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            <Timeline 
              logs={logs} 
              traces={traces} 
              viewMode={viewMode} 
              activeIndex={currentIndex} 
              onSelect={setCurrentIndex} 
            />
          </div>
        </section>

        {/* Center Panel: The State */}
        <section className="flex-1 flex flex-col bg-zinc-950/40">
          <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-zinc-400 font-medium text-xs uppercase tracking-wider">
              <Box size={14} />
              The State
            </div>
            {activeLog && (
              <div className="flex items-center gap-3 text-[10px] font-mono text-zinc-500">
                <span className="bg-zinc-800 px-2 py-0.5 rounded uppercase">{activeLog.level}</span>
                <span>{activeLog.component || 'System'}</span>
              </div>
            )}
          </div>
          <div className="flex-1 overflow-y-auto">
             <StateViewer log={activeLog} allLogs={logs} index={currentIndex} />
          </div>
        </section>

        {/* Right Panel: The Inspector */}
        <section className="w-[400px] border-l border-zinc-800 flex flex-col shrink-0 bg-zinc-950/20">
          <div className="p-4 border-b border-zinc-800 flex items-center gap-2 text-zinc-400 font-medium text-xs uppercase tracking-wider">
            <Terminal size={14} />
            Inspector
          </div>
          <div className="flex-1 overflow-y-auto">
            <Inspector log={activeLog} />
          </div>
        </section>
      </main>

      {/* Footer / Playback Controls */}
      <footer className="h-20 border-t border-zinc-800 bg-zinc-950 p-4 flex flex-col justify-center shrink-0 shadow-[0_-10px_20px_-10px_rgba(0,0,0,0.5)]">
        <div className="flex items-center gap-6 max-w-6xl mx-auto w-full">
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setCurrentIndex(Math.max(0, currentIndex - 1))}
              className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-colors"
            >
              <Rewind size={18} fill="currentColor" />
            </button>
            <button 
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-10 h-10 bg-emerald-500 text-zinc-950 rounded-full flex items-center justify-center hover:bg-emerald-400 transition-all active:scale-95 shadow-lg shadow-emerald-500/10"
            >
              {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-1" />}
            </button>
            <button 
               onClick={() => setCurrentIndex(Math.min(logs.length - 1, currentIndex + 1))}
              className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-colors"
            >
              <FastForward size={18} fill="currentColor" />
            </button>
          </div>

          <div className="flex-1 flex flex-col gap-1.5">
            <div className="flex justify-between text-[10px] font-mono text-zinc-500 uppercase tracking-tighter">
              <div className="flex gap-4">
                 <span>Step: {currentIndex + 1} / {logs.length}</span>
                 {activeLog && <span>Time: {new Date(activeLog.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit', fractionalSecondDigits: 3 } as any)}</span>}
              </div>
              <span>{Math.round(((currentIndex + 1) / logs.length) * 100)}% Execution</span>
            </div>
            <div className="relative h-2 bg-zinc-800 rounded-full group cursor-pointer overflow-hidden border border-zinc-700/50">
               <input 
                 type="range" 
                 min="0" 
                 max={logs.length - 1} 
                 value={currentIndex}
                 onChange={(e) => setCurrentIndex(parseInt(e.target.value))}
                 className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
               />
               <div 
                 className="absolute top-0 left-0 h-full bg-emerald-500 transition-all duration-200"
                 style={{ width: `${((currentIndex + 1) / logs.length) * 100}%` }}
               />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
